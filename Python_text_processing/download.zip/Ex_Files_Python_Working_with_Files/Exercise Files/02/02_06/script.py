
def find_most_common_word():