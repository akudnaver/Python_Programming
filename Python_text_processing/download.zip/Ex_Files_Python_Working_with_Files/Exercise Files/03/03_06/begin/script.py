
def generate_dictionary(monster_name, title, price, scariness):
	return {'monster_name': monster_name, 'title': title, 
	'price': price, 'scariness': scariness}
